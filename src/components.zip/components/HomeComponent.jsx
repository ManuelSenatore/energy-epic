import React from 'react'

function HomeComponent() {
  return (
    <div>
      <h1>Chitammuooo</h1>
    </div>
  )
}

export default HomeComponent
