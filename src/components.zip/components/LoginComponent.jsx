import React, { useState } from "react";
import { Form, Button } from "react-bootstrap";
import { useNavigate } from "react-router-dom"
function LoginComponent() {

    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');

    const navigate = useNavigate()

 const fetchUser = () => {
        const baseEndpoint = "http://localhost:8080/auth/login";
        const header = {
          "Content-type": "application/json"
        };
        const body = {
            username : username,
            password : password
        }
      
        return async () => {
          try {
            const response = await fetch(baseEndpoint, {
              method: "POST",
              headers: header,
              body: body
            });
            if (response.ok) {
              const data = await response.json();
              console.log(data);
            } else {
              alert("Error fetching results");
            }
          } catch (error) {
            console.log(error);
          }
        };
      };


  return (
    <div>
      <Form>
        <Form.Group className="mb-3" controlId="formBasicEmail">
          <Form.Label>Email address</Form.Label>
          <Form.Control
           value={username}
           onChange={(e) => setUsername(e.target.username)}
            type="text"
            placeholder="Enter username" />
          <Form.Text className="text-muted">
            We'll never share your email with anyone else.
          </Form.Text>
        </Form.Group>

        <Form.Group className="mb-3" controlId="formBasicPassword">
          <Form.Label>Password</Form.Label>
          <Form.Control
           value={password}
           onChange={(e) => setPassword(e.target.password)}
            type="password"
             placeholder="Password" />
        </Form.Group>
        <Button onClick={() => {fetchUser() ; navigate('/home')}} on variant="primary" type="submit">
          Submit
        </Button>
      </Form>
    </div>
  );
}

export default LoginComponent;
